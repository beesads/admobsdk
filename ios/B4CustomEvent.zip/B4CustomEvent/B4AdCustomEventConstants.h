//
//  B4AdCustomEventConstants.h
//  AdmobMediation
//

#ifndef B4AdCustomEventConstants_h
#define B4AdCustomEventConstants_h

static NSString *const B4AdSDKVersion = @"1.0.0";
/// Version for the Custom Event Adapter
static NSString *const B4AdCustomEventAdapterVersion = @"1.0.0.0";
#endif /* Ad4CustomEventConstants_h */


