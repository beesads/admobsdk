//
//  B4AdCustomEvent.m
//  AdmobMediation
//
//

#import "B4AdCustomEvent.h"
#import "B4AdCustomEventIntertitial.h"
#import "B4AdCustomEventBanner.h"
#import "B4AdCustomEventRewarded.h"
#import "B4AdCustomEventNativeAd.h"

@implementation B4AdCustomEvent{
    B4AdCustomEventRewarded *b4AdRewarded;
    B4AdCustomEventIntertitial *b4AdIntertitial;
    B4AdCustomEventBanner *b4AdBanner;
    B4AdCustomEventNativeAd *b4AdNative;
}

+ (void)setUpWithConfiguration:(nonnull GADMediationServerConfiguration *)configuration
             completionHandler:(nonnull GADMediationAdapterSetUpCompletionBlock)completionHandler {
  // This is where you initialize the SDK that this custom event is built
  // for. Upon finishing the SDK initialization, call the completion handler
  // with success.
  completionHandler(nil);
}

#pragma mark GADMediationAdapter implementation

+ (GADVersionNumber)adSDKVersion {
  NSArray *versionComponents = [B4AdSDKVersion componentsSeparatedByString:@"."];
  GADVersionNumber version = {0};
  if (versionComponents.count >= 3) {
    version.majorVersion = [versionComponents[0] integerValue];
    version.minorVersion = [versionComponents[1] integerValue];
    version.patchVersion = [versionComponents[2] integerValue];
  }
  return version;
}

+ (GADVersionNumber)adapterVersion {
  NSArray *versionComponents = [B4AdCustomEventAdapterVersion componentsSeparatedByString:@"."];
  GADVersionNumber version = {0};
  if (versionComponents.count == 4) {
    version.majorVersion = [versionComponents[0] integerValue];
    version.minorVersion = [versionComponents[1] integerValue];
    version.patchVersion =
        [versionComponents[2] integerValue] * 100 + [versionComponents[3] integerValue];
  }
  return version;
}

- (void)loadInterstitialForAdConfiguration:
            (GADMediationInterstitialAdConfiguration *)adConfiguration
                         completionHandler:
                             (GADMediationInterstitialLoadCompletionHandler)completionHandler {
    b4AdIntertitial = [[B4AdCustomEventIntertitial alloc] init];
    [b4AdIntertitial loadInterstitialForAdConfiguration:adConfiguration completionHandler:completionHandler];
}

- (void)loadBannerForAdConfiguration:(GADMediationBannerAdConfiguration *)adConfiguration
                   completionHandler:(GADMediationBannerLoadCompletionHandler)completionHandler {
    b4AdBanner = [[B4AdCustomEventBanner alloc] init];
  [b4AdBanner loadBannerForAdConfiguration:adConfiguration completionHandler:completionHandler];
}

- (void)loadRewardedAdForAdConfiguration:(GADMediationRewardedAdConfiguration *)adConfiguration
                       completionHandler:
                           (GADMediationRewardedLoadCompletionHandler)completionHandler {
  b4AdRewarded = [[B4AdCustomEventRewarded alloc] init];
  [b4AdRewarded loadRewardedAdForAdConfiguration:adConfiguration
                                 completionHandler:completionHandler];
}

- (void)loadNativeAdForAdConfiguration:(GADMediationNativeAdConfiguration *)adConfiguration
                      completionHandler:
                          (GADMediationNativeLoadCompletionHandler)completionHandler {
  b4AdNative = [[B4AdCustomEventNativeAd alloc] init];
  [b4AdNative loadNativeAdForAdConfiguration:adConfiguration
                                completionHandler:completionHandler];
}

@end
