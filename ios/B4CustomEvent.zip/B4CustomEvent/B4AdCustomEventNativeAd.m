//
//
// B4AdCustomEventNativeAd.m
//

#import "B4AdCustomEventNativeAd.h"
#include <stdatomic.h>
#import <Foundation/Foundation.h>

@interface B4AdCustomEventNativeAd () <GADAdLoaderDelegate,
                                       GADCustomNativeAdLoaderDelegate,
                                       GADNativeAdLoaderDelegate,
                                       GADNativeAdDelegate,
                                       GADVideoControllerDelegate> {
    GADMediationNativeLoadCompletionHandler _loadCompletionHandler;

    /// The ad event delegate to forward ad rendering events to the Google Mobile Ads SDK.
    id<GADMediationNativeAdEventDelegate> _adEventDelegate;

    /// Native ad view options.
    GADNativeAdViewAdOptions *_nativeAdViewAdOptions;

    /// The native ad object
    GADNativeAd *_nativeAd;
  }
 
  @property(nonatomic, strong) GADAdLoader *adLoader;
  @property(nonatomic, strong) UIView *nativeAdView;

  @end

  @implementation B4AdCustomEventNativeAd

//  /// Used to store the ad's images. In order to implement the GADMediationNativeAd protocol, we use
//  /// this class to return the images property.
//  NSArray<GADNativeAdImage *> *_images;
//
//  /// Used to store the ad's icon. In order to implement the GADMediationNativeAd protocol, we use
//  /// this class to return the icon property.
//  GADNativeAdImage *_icon;
//
//  /// Used to store the ad's ad choices view. In order to implement the GADMediationNativeAd protocol,
//  /// we use this class to return the adChoicesView property.
//  UIView *_adChoicesView;

  - (nullable NSString *)headline {
    return _nativeAd.headline;
  }

  - (nullable NSArray<GADNativeAdImage *> *)images {
    return _nativeAd.images;
  }

  - (nullable NSString *)body {
    return _nativeAd.body;
  }

  - (nullable GADNativeAdImage *)icon {
    return _nativeAd.icon;
  }

  - (nullable NSString *)callToAction {
    return _nativeAd.callToAction;
  }

  - (nullable NSDecimalNumber *)starRating {
    return _nativeAd.starRating;
  }

  - (nullable NSString *)store {
    return _nativeAd.store;
  }

  - (nullable NSString *)price {
    return _nativeAd.price;
  }

  - (nullable NSString *)advertiser {
    return _nativeAd.advertiser;
  }

  - (nullable NSDictionary<NSString *, id> *)extraAssets {
    return nil;
  }
 
- (GADMediaContent *)mediaContent {
    return _nativeAd.mediaContent;
}
//  - (nullable UIView *)adChoicesView {
//    return _nativeAd.ad;
//  }

//  - (nullable UIView *)mediaView {
//    return _nativeAd.mediaView;
//  }
//
//  - (BOOL)hasVideoContent {
//    return self.mediaView != nil;
//  }

  - (void)loadNativeAdForAdConfiguration:(GADMediationNativeAdConfiguration *)adConfiguration
                       completionHandler:(GADMediationNativeLoadCompletionHandler)completionHandler {
      __block atomic_flag completionHandlerCalled = ATOMIC_FLAG_INIT;
      __block GADMediationNativeLoadCompletionHandler originalCompletionHandler =
          [completionHandler copy];

      _loadCompletionHandler = ^id<GADMediationNativeAdEventDelegate>(
          _Nullable id<GADMediationNativeAd> ad, NSError *_Nullable error) {
        // Only allow completion handler to be called once.
        if (atomic_flag_test_and_set(&completionHandlerCalled)) {
          return nil;
        }

        id<GADMediationNativeAdEventDelegate> delegate = nil;
        if (originalCompletionHandler) {
          // Call original handler and hold on to its return value.
          delegate = originalCompletionHandler(ad, error);
        }

        // Release reference to handler. Objects retained by the handler will also be released.
        originalCompletionHandler = nil;

        return delegate;
      };
      
    NSMutableArray *adTypes = [[NSMutableArray alloc] init];
    [adTypes addObject:GADAdLoaderAdTypeNative];
//    [adTypes addObject:GADAdLoaderAdTypeCustomNative];
    GADVideoOptions *videoOptions = [[GADVideoOptions alloc] init];
    videoOptions.startMuted = NO;
    NSString *adUnit = adConfiguration.credentials.settings[@"parameter"];
    self.adLoader = [[GADAdLoader alloc] initWithAdUnitID:adUnit
                                         rootViewController:UIApplication.sharedApplication.keyWindow.rootViewController
                                                    adTypes:adTypes
                                                    options:nil]; //@[videoOptions]
      self.adLoader.delegate = self;
      [self.adLoader loadRequest:[GADRequest request]];

  }

  // Indicates if the custom event handles user clicks. Return YES if the custom event should handle
  // user clicks.
  - (BOOL)handlesUserClicks {
    return NO;
  }

  - (BOOL)handlesUserImpressions {
    return NO;
  }



#pragma mark GADAdLoaderDelegate implementation

- (void)adLoader:(GADAdLoader *)adLoader didFailToReceiveAdWithError:(NSError *)error {
  NSLog(@"%@ failed with error: %@", adLoader, [error localizedDescription]);
  _adEventDelegate = _loadCompletionHandler(nil, error);
}

#pragma mark GADNativeAdLoaderDelegate implementation

- (void)adLoader:(GADAdLoader *)adLoader didReceiveNativeAd:(GADNativeAd *)nativeAd {
    NSLog(@"Received native ad: %@", nativeAd);
    // Set ourselves as the ad delegate to be notified of native ad events.
    _nativeAd = nativeAd;
    nativeAd.delegate = self;
    
//    if (nativeAd.mediaContent.hasVideoContent) {
//        // By acting as the delegate to the GADVideoController, this ViewController
//        // receives messages about events in the video lifecycle.
//        nativeAd.mediaContent.videoController.delegate = self;
//    }
    _adEventDelegate = _loadCompletionHandler(self, nil);
}

#pragma mark GADCustomNativeAdLoaderDelegate implementation

- (void)adLoader:(nonnull GADAdLoader *)adLoader
    didReceiveCustomNativeAd:(nonnull GADCustomNativeAd *)customNativeAd {
  NSLog(@"Received custom native ad: %@", customNativeAd);
}

- (nonnull NSArray<NSString *> *)customNativeAdFormatIDsForAdLoader:
    (nonnull GADAdLoader *)adLoader {
    return nil;
}

#pragma mark GADNativeAdDelegate

- (void)nativeAdDidRecordClick:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate reportClick];
}

- (void)nativeAdDidRecordImpression:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate reportImpression];
}

- (void)nativeAdWillPresentScreen:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate willPresentFullScreenView];
}

- (void)nativeAdWillDismissScreen:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate willDismissFullScreenView];
}

- (void)nativeAdDidDismissScreen:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate didDismissFullScreenView];
}

- (void)nativeAdWillLeaveApplication:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
}
@end
