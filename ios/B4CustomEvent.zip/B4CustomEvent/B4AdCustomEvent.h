//
//  B4AdCustomEvent.h
//  AdmobMediation
//
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "B4AdCustomEventConstants.h"
NS_ASSUME_NONNULL_BEGIN

@interface B4AdCustomEvent : NSObject<GADMediationAdapter>

@end

NS_ASSUME_NONNULL_END
