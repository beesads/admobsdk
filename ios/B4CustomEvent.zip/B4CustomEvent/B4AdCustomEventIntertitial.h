//
//  B4AdCustomEventIntertitial.h
//  AdmobMediation


#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
NS_ASSUME_NONNULL_BEGIN

@interface B4AdCustomEventIntertitial : NSObject
- (void)loadInterstitialForAdConfiguration:
            (GADMediationInterstitialAdConfiguration *)adConfiguration
                         completionHandler:
                             (GADMediationInterstitialLoadCompletionHandler)completionHandler;
@end

NS_ASSUME_NONNULL_END
