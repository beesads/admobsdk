//
//  B4AdCustomEventRewarded.h
//  AdmobMediation
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
NS_ASSUME_NONNULL_BEGIN

@interface B4AdCustomEventRewarded : NSObject
- (void)loadRewardedAdForAdConfiguration:(GADMediationRewardedAdConfiguration *)adConfiguration
                       completionHandler:
                           (GADMediationRewardedLoadCompletionHandler)completionHandler;
@end

NS_ASSUME_NONNULL_END
